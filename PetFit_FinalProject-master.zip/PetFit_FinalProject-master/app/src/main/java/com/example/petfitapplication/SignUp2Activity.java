package com.example.petfitapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.airbnb.lottie.LottieAnimationView;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

public class SignUp2Activity extends AppCompatActivity {

    private Button nextBtn2;
    private TextView petSavedTextView;
    private TextView detailsTextView;
    private EditText emailEditText;
    private EditText nameEditText;
    private EditText passwordEditText;

    private LottieAnimationView checkmarkAnimationView;
    private FirebaseAuth mAuth;
    private TextInputLayout passwordLayout;
    private TextView errorTextView;
    private FirebaseDatabaseHelper databaseHelper;
    private DatabaseReference databaseReference;
    @Override
    public void onStart() {
        super.onStart();
        // Check if user is already logged in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            startActivity(new Intent(SignUp2Activity.this, MainActivity.class));
            finish();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up2);

        mAuth = FirebaseAuth.getInstance();
        databaseHelper = new FirebaseDatabaseHelper();

        nextBtn2 = findViewById(R.id.nextBtn2);
        petSavedTextView = findViewById(R.id.textView24);
        detailsTextView = findViewById(R.id.textView27);
        emailEditText = findViewById(R.id.emailAdd);
        nameEditText = findViewById(R.id.fullName);
        passwordEditText = findViewById(R.id.password);
        passwordLayout = findViewById(R.id.passwordLayout);
        checkmarkAnimationView = findViewById(R.id.checkmarkAnimationView);
        errorTextView = findViewById(R.id.errorText);

        nextBtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get the user's name, email, and password.
                String name = String.valueOf(nameEditText.getText());
                String email = String.valueOf(emailEditText.getText());
                String password = String.valueOf(passwordEditText.getText());

                if (TextUtils.isEmpty(email)) {
                    Toast.makeText(SignUp2Activity.this, "Enter an email", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(password)) {
                    Toast.makeText(SignUp2Activity.this, "Enter a password", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(name)) {
                    Toast.makeText(SignUp2Activity.this, "Enter your full name", Toast.LENGTH_SHORT).show();
                    return;
                }


                // Use Firebase to register and login.
                mAuth.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Sign up success
                                    Toast.makeText(SignUp2Activity.this, "Account created.", Toast.LENGTH_SHORT).show();

                                    // Save user info to the database and MemoryData
                                    String uid = mAuth.getCurrentUser().getUid();
                                    databaseHelper.saveUserInfo(uid, name, email,"");
                                    MemoryData.saveData(email,SignUp2Activity.this);
                                    MemoryData.saveName(name,SignUp2Activity.this);

                                    // Update the progress bar to 100%
                                    ProgressBar progressBar = findViewById(R.id.progressBar);
                                    progressBar.setProgress(100);

                                    // Change text and visibility
                                    petSavedTextView.setText("Complete!");
                                    detailsTextView.setVisibility(View.GONE);
                                    emailEditText.setVisibility(View.GONE);
                                    nameEditText.setVisibility(View.GONE);
                                    passwordEditText.setVisibility(View.GONE);
                                    errorTextView.setVisibility(View.GONE);
                                    passwordLayout.setPasswordVisibilityToggleEnabled(false);
                                    checkmarkAnimationView.setVisibility(View.VISIBLE);

                                    // Start animation
                                    checkmarkAnimationView.setAnimation(R.raw.complete);
                                    checkmarkAnimationView.playAnimation();

                                    // Change button text and set click listener
                                    nextBtn2.setText("Done");
                                    nextBtn2.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View view) {
                                            Intent intent = new Intent(SignUp2Activity.this, LoginActivity.class);
                                            intent.putExtra("email", email);
                                            intent.putExtra("name", name);
                                            startActivity(intent);
                                            finish(); // Optional: finish the current activity if needed
                                        }
                                    });

                                } else {
                                    // If sign up fails, display the error message.
                                    try {
                                        throw task.getException();
                                    } catch (FirebaseAuthUserCollisionException emailExistEx) {
                                        String errorMessage = "The email address is already in use by another account.";
                                        errorTextView.setText(errorMessage);
                                        errorTextView.setVisibility(View.VISIBLE);
                                    } catch (Exception ex) {
                                        // Handle other exceptions if needed
                                    }
                                }
                            }
                        });

            }
        });
    }
}
