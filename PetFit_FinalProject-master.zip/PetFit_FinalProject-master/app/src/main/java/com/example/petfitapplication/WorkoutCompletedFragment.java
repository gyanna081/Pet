package com.example.petfitapplication;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

import com.example.petfitapplication.R;

public class WorkoutCompletedFragment extends DialogFragment {

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();

        View view = inflater.inflate(R.layout.fragment_workout_completed, null);

        TextView tvCongratulations = view.findViewById(R.id.tvCongratulations);
        TextView tvWorkoutSummary = view.findViewById(R.id.tvWorkoutSummary);

        tvCongratulations.setText("Congratulations!"); // Set the congratulations text
        tvWorkoutSummary.setText("You walked 3.2 miles and burned 200 kcal"); // Set the workout summary

        ImageButton btnClose = view.findViewById(R.id.btnClose);
        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
                Intent intent = new Intent(getActivity(), TrainingPage2Activity.class);
                startActivity(intent);
                getActivity().finish();
            }
        });

        builder.setView(view);
        return builder.create();
    }
}
