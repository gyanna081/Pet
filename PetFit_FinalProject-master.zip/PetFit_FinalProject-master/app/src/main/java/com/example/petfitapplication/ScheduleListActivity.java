package com.example.petfitapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ScheduleListActivity extends AppCompatActivity {

    private ListView listViewSchedule;
    private List<String> scheduleList;
    private ArrayAdapter<String> scheduleAdapter;
    private SharedPreferences sharedPreferences;
    private static final String PREFS_NAME = "SchedulePrefs";
    private static final String SCHEDULE_KEY = "Schedules";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule_list);

        Button homebtn = findViewById(R.id.backButton8);

        homebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ScheduleListActivity.this, MainActivity.class));
            }
        });

        listViewSchedule = findViewById(R.id.listViewSchedule);
        scheduleList = new ArrayList<>();  // Initialize the scheduleList
        scheduleAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, scheduleList);
        listViewSchedule.setAdapter(scheduleAdapter);

        // Retrieve the scheduledDateTime from the intent extras
        String scheduledDateTime = getIntent().getStringExtra("scheduledDateTime");

        // Load existing schedules from shared preferences
        loadSchedules();

        // Add the new schedule
        addScheduleToList(scheduledDateTime);

        // Save the updated schedules to shared preferences
        saveSchedules();
    }

    private void loadSchedules() {
        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        Set<String> scheduleSet = sharedPreferences.getStringSet(SCHEDULE_KEY, new HashSet<>());
        scheduleList.addAll(scheduleSet);
    }

    private void saveSchedules() {
        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        // Remove any null values from the scheduleList
        scheduleList.removeAll(Collections.singleton(null));

        Set<String> scheduleSet = new HashSet<>(scheduleList);
        editor.putStringSet(SCHEDULE_KEY, scheduleSet);
        editor.apply();
    }

    private void addScheduleToList(String scheduledDateTime) {
        if (scheduledDateTime != null) {
            // Add the scheduledDateTime to the beginning of the list
            scheduleList.add(0, scheduledDateTime);
            scheduleAdapter.notifyDataSetChanged();
        } else {
            // Handle the case when scheduledDateTime is null
            // For example, you could show a toast message or log an error.
            // Here's an example of showing a toast message:
            Toast.makeText(this, "Opened Schedule", Toast.LENGTH_SHORT).show();
        }
    }
}
