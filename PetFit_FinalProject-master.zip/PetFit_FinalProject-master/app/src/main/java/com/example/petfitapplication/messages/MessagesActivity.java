package com.example.petfitapplication.messages;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.petfitapplication.CommunityActivity;
import com.example.petfitapplication.R;
import com.example.petfitapplication.TrainingActivity;
import com.example.petfitapplication.TrainingPage2Activity;
import com.example.petfitapplication.chat.Chat;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class MessagesActivity extends AppCompatActivity implements MessagesAdapter.OnItemClickListener {
    private List<MessageList> messagesLists;
    private String uid;
    private RecyclerView messagesRecyclerView;

    // Initialize Firebase
    private FirebaseDatabase database = FirebaseDatabase.getInstance("https://pet-fit-673a5-default-rtdb.asia-southeast1.firebasedatabase.app");
    private DatabaseReference databaseReference = database.getReference();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_messages);


        TextView comm = findViewById(R.id.textView21);
        comm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MessagesActivity.this, CommunityActivity.class));
            }
        });

        CircleImageView userProfilePic = findViewById(R.id.userProfilePic);
        messagesRecyclerView = findViewById(R.id.messagesRecyclerView);

        // Get intent data from Register/Sign Up
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            uid = currentUser.getUid();
        }

        messagesRecyclerView.setHasFixedSize(true);
        messagesRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        messagesLists = new ArrayList<>();

        // Retrieve profile pic from Firebase Realtime Database
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String profilePicUrl = snapshot.child("users").child(uid).child("profile_pic").getValue(String.class);
                if (profilePicUrl != null) {
                    Picasso.get().load(profilePicUrl).into(userProfilePic);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle onCancelled event
            }
        });

        // Retrieve messages from Firebase Realtime Database
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                messagesLists.clear();

                for (DataSnapshot dataSnapshot : snapshot.child("users").getChildren()) {
                    String getUID = dataSnapshot.getKey();

                    if (!getUID.equals(uid)) {
                        String getName = dataSnapshot.child("name").getValue(String.class);
                        String getProfilePic = dataSnapshot.child("profile_pic").getValue(String.class);

                        MessageList messagesList = new MessageList(getName, getUID, "", getProfilePic, 0);
                        messagesLists.add(messagesList);
                    }
                }

                MessagesAdapter adapter = new MessagesAdapter(messagesLists, MessagesActivity.this, MessagesActivity.this);
                messagesRecyclerView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle onCancelled event
            }
        });

        // Back button click listener
        ImageButton backBtn = findViewById(R.id.backBtn);
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    @Override
    public void onItemClick(MessageList messageList) {
        // Handle item click event
        Toast.makeText(this, "Clicked on user: " + messageList.getName(), Toast.LENGTH_SHORT).show();

        // Add your logic for navigating to the chat activity and passing necessary data
        Intent intent = new Intent(MessagesActivity.this, Chat.class);
        intent.putExtra("userId", messageList.getEmail()); // Assuming the email is the user ID
        startActivity(intent);
    }



}