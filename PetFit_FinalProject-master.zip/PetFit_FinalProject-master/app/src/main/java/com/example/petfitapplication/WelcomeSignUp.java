package com.example.petfitapplication;

import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class WelcomeSignUp extends AppCompatActivity {
    private FirebaseAuth mAuth;
    @Override
    public void onStart() {
        super.onStart();
        // Check if user is already logged in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if(currentUser != null){
            Toast.makeText(WelcomeSignUp.this,"Welcome Back!",Toast.LENGTH_SHORT).show();
            startActivity(new Intent(WelcomeSignUp.this,MainActivity.class));
            finish();
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_sign_up);

        mAuth = FirebaseAuth.getInstance();

        TextView signinBtn = findViewById(R.id.textViewSignIn);
        Button signupBtn = findViewById(R.id.signupBtn);

        //para nay underline ang "sign in" na word para chuyens
        signinBtn.setPaintFlags(signinBtn.getPaintFlags() |   Paint.UNDERLINE_TEXT_FLAG);

        //ig click sa sign in mo adto siyas sign in page
        signinBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(WelcomeSignUp.this,LoginActivity.class));
            }
        });

        signupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(WelcomeSignUp.this,SignUpActivity.class));
            }
        });
    }
}