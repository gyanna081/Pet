package com.example.petfitapplication;

import android.util.Log;

import androidx.annotation.NonNull;

import com.example.petfitapplication.User;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class FirebaseDatabaseHelper {
    private DatabaseReference usersRef;

    public FirebaseDatabaseHelper() {
        FirebaseDatabase database = FirebaseDatabase.getInstance("https://pet-fit-673a5-default-rtdb.asia-southeast1.firebasedatabase.app");
        usersRef = database.getReference("users");
    }

    public void saveUserInfo(String userId, String name, String email, String profile_pic) {
        User user = new User(name, email, profile_pic);
        usersRef.child(userId).setValue(user)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        // User information saved successfully
                        Log.d("FirebaseDatabaseHelper", "User information saved successfully");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // An error occurred while saving user information
                        // Handle the error appropriately
                        Log.e("FirebaseDatabaseHelper", "Error saving user information", e);
                    }
                });
    }


}
