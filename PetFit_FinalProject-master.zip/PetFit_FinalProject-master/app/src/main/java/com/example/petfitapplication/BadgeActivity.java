package com.example.petfitapplication;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class BadgeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_badge_activity);

        ImageButton btnClose = findViewById(R.id.btnClose);
        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle the close button click
                SharedPreferences sharedPreferences = getSharedPreferences("com.example.petfitapplication", MODE_PRIVATE);
                sharedPreferences.edit().putBoolean("isBadgeActivityShown", true).apply();
                finish();
            }
        });
    }
}
