package com.example.petfitapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class TrainingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_training);


        Button Trainingbtn3 = findViewById(R.id.button2);

        Trainingbtn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(TrainingActivity.this, TrainingPage4Activity.class));

            }
        });

        ImageButton backButton = findViewById(R.id.imageButton4);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(TrainingActivity.this, MainActivity.class));
            }
        });


        Button Trainingbtn2 = findViewById(R.id.ButtonPlay);

        Trainingbtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(TrainingActivity.this, TrainingPage3.class));

            }
        });

        Button Trainingbtn = findViewById(R.id.ButtonViewmore);
        Trainingbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(TrainingActivity.this, TrainingPage2Activity.class));

            }
        });

        Button seeAll = findViewById(R.id.button);
        seeAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(TrainingActivity.this, ScheduleListActivity.class));

            }
        });
    }
}