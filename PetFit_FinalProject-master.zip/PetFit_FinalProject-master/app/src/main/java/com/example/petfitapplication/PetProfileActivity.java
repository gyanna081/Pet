package com.example.petfitapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;
import android.widget.Button;

public class PetProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pet_profile);

        Button backButton = findViewById(R.id.backButton);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Handles back button click event
                onBackPressed();
            }
        });
    }
    public void onProfileImageClick(View view) {
        // Handle profile image click event
    }

    public void onGenderClick(View view) {
        // Handles gender button click event
    }

    public void onWeightClick(View view) {
        // Handles weight button click event
    }

    public void onAgeClick(View view) {
        // Handles age button click event
    }

    public void onAchievementsClick(View view) {
        // Handles achievements button click event
    }

    public void onWorkoutProgressClick(View view) {
        // Handles workout progress button click event
    }

    public void onActivityHistoryClick(View view) {
        // Handle activity history button click event
    }
}
