package com.example.petfitapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ScheduledActivity extends AppCompatActivity {

    private TextView textViewSuccessMessage;
    private TextView textViewScheduledDateTime;
    private TextView textViewScheduledDescription;
    private ProgressBar progressBar;
    private static final long LOADING_DELAY_MS = 2000; // 2 seconds
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scheduled);

        textViewSuccessMessage = findViewById(R.id.textViewSuccessMessage);
        textViewScheduledDateTime = findViewById(R.id.textViewScheduledDateTime);
        textViewScheduledDescription = findViewById(R.id.textViewScheduledDescription);
        progressBar = findViewById(R.id.progressBarLoading);


        showLoadingScreen();

        // Retrieve the scheduled date and time from the intent extras
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // Retrieve the scheduled date and time from the intent extras
                String scheduledDateTime = getIntent().getStringExtra("scheduledDateTime");
                String selectedOption = getIntent().getStringExtra("selectedOption");

                // Hide the loading screen and show the scheduled workout
                hideLoadingScreen();
                showScheduledWorkout(scheduledDateTime, selectedOption);

                goToTrainingActivity();
            }
        }, LOADING_DELAY_MS);

    }


    private void showLoadingScreen() {
        textViewSuccessMessage.setText("Loading...");
        textViewSuccessMessage.setTextColor(getResources().getColor(android.R.color.holo_orange_light));
        textViewScheduledDateTime.setText("");
        textViewScheduledDescription.setText("");
        progressBar.setVisibility(View.VISIBLE);
    }

    private void hideLoadingScreen() {
        textViewSuccessMessage.setText("Workout Scheduled created successfully");
        textViewSuccessMessage.setTextColor(getResources().getColor(android.R.color.black));
        progressBar.setVisibility(View.GONE);
    }

    private void showScheduledWorkout(String scheduledDateTime, String selectedOption) {
        String formattedDateTime = formatDate(scheduledDateTime);
        String scheduledWorkout = String.format("%s-%s", selectedOption, formattedDateTime);

        textViewScheduledDateTime.setText(scheduledWorkout);
        textViewScheduledDateTime.setMaxLines(2); // Set maximum lines to 2
        textViewScheduledDateTime.setEllipsize(TextUtils.TruncateAt.END); // Add ellipsis at the end if the text exceeds 2 lines
        textViewScheduledDescription.setText("This is your scheduled workout!");
    }

    private String formatDate(String scheduledDateTime) {
        // Implement the desired formatting logic for the scheduled date and time
        // For example, you can use SimpleDateFormat to format the date and time in a specific pattern
        SimpleDateFormat inputFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy", Locale.US);
        SimpleDateFormat outputFormat = new SimpleDateFormat("MMM dd, yyyy, hh:mm a", Locale.US);

        try {
            Date date = inputFormat.parse(scheduledDateTime);
            return outputFormat.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return scheduledDateTime;
    }



    private void goToTrainingActivity() {
        // Delay duration in milliseconds
        long delayDuration = 2000; // 2 seconds

        // Create a Handler to introduce a delay before navigating
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(ScheduledActivity.this, ScheduleListActivity.class);
                // Create an Intent to launch the TrainingActivity
                // Pass the scheduledDateTime value as an extra
                String scheduledDateTime = textViewScheduledDateTime.getText().toString();
                intent.putExtra("scheduledDateTime", scheduledDateTime);
                startActivity(intent);
                finish(); // Optional: Finish the current activity to prevent going back to it
            }
        }, delayDuration);
    }
}
