package com.example.petfitapplication;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;

import com.airbnb.lottie.LottieAnimationView;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;
import com.google.firebase.auth.FirebaseUser;

import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private EditText emailEditText;
    private EditText passwordEditText;
    private FirebaseAuth mAuth;
    private TextView forgotPassText;

    private ProgressDialog progressDialog;
    @Override
    public void onStart() {
        super.onStart();
        // Check if user is already logged in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if(currentUser != null){
            startActivity(new Intent(LoginActivity.this,MainActivity.class));
            finish();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mAuth = FirebaseAuth.getInstance();
        emailEditText = findViewById(R.id.email);
        passwordEditText = findViewById(R.id.passwordEditText);
        forgotPassText = findViewById(R.id.forgotText);

        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Logging in...");
        Button loginBtn = findViewById(R.id.loginBtn);
        TextView signupBtn = findViewById(R.id.signupText);

        // Set underline for "sign up" text
        signupBtn.setPaintFlags(signupBtn.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = String.valueOf(emailEditText.getText());
                String password = String.valueOf(passwordEditText.getText());

                if (TextUtils.isEmpty(email)){
                    Toast.makeText(LoginActivity.this,"Enter an email",Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(password)){
                    Toast.makeText(LoginActivity.this,"Enter a password",Toast.LENGTH_SHORT).show();
                    return;
                }

                progressDialog.show();
                mAuth.signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Sign in success
                                    progressDialog.dismiss();
                                    Toast.makeText(getApplicationContext(), "You are now logged in.", Toast.LENGTH_SHORT).show();
                                    startActivity(new Intent(LoginActivity.this, MainActivity.class));
                                    finish();
                                } else {
                                    // If sign in fails, display a message to the user
                                    progressDialog.dismiss();
                                    try {
                                        throw task.getException();
                                    } catch (FirebaseAuthInvalidUserException invalidEmail) {
                                        // Handle invalid email exception
                                        setErrorText("Account doesn't exist");
                                    } catch (FirebaseAuthInvalidCredentialsException wrongPassword) {
                                        // Handle wrong password exception
                                        setErrorText("Invalid password");
                                    } catch (Exception e) {
                                        // Handle other exceptions
                                        setErrorText("Authentication failed");
                                    }
                                }
                            }
                        });
            }
        });

        signupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LoginActivity.this,SignUpActivity.class));
            }
        });

        forgotPassText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = String.valueOf(emailEditText.getText());
                mAuth.sendPasswordResetEmail(email)
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(getApplicationContext(), "Email sent.", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
        });
    }

    private void setErrorText(String message) {
        TextView errorText = findViewById(R.id.errorText);
        errorText.setText(message);
        errorText.setVisibility(View.VISIBLE);
        errorText.setTextColor(Color.RED);
        errorText.setGravity(Gravity.CENTER);
    }
}
