package com.example.petfitapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class TimeAdapter extends ArrayAdapter<String> {
    private LayoutInflater inflater;
    private int resource;

    public TimeAdapter(Context context, int resource, String[] timeValues) {
        super(context, resource, timeValues);
        this.inflater = LayoutInflater.from(context);
        this.resource = resource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;

        if (convertView == null) {
            convertView = inflater.inflate(resource, parent, false);

            viewHolder = new ViewHolder();
            viewHolder.textViewHour = convertView.findViewById(R.id.textViewHour);
            viewHolder.textViewMinutes = convertView.findViewById(R.id.textViewMinutes);
            viewHolder.textViewAmPm = convertView.findViewById(R.id.textViewAmPm);

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        // Get the time value at the current position
        String timeValue = getItem(position);

        // Split the time value into hour, minutes, and AM/PM parts
        String[] parts = timeValue.split("\\|");
        String hour = parts[0].trim();
        String minutes = parts[1].trim();
        String amPm = parts[2].trim();

        // Set the hour, minutes, and AM/PM values in the TextViews
        viewHolder.textViewHour.setText(hour);
        viewHolder.textViewMinutes.setText(minutes);
        viewHolder.textViewAmPm.setText(amPm);

        return convertView;
    }

    private static class ViewHolder {
        TextView textViewHour;
        TextView textViewMinutes;
        TextView textViewAmPm;
    }
}