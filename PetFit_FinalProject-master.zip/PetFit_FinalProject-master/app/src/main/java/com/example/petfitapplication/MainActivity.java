package com.example.petfitapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.example.petfitapplication.messages.MessagesActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity extends AppCompatActivity {
    private DatabaseReference mDatabase;
    private TextView helloName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize Firebase
        FirebaseDatabase database = FirebaseDatabase.getInstance("https://pet-fit-673a5-default-rtdb.asia-southeast1.firebasedatabase.app");
        mDatabase = database.getReference();
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        String userId = currentUser.getUid();

        helloName = findViewById(R.id.helloName);

        final ImageButton userProfilePic = findViewById(R.id.UserProfilebtn);

        // Get profile pic from Firebase Realtime Database
        mDatabase.child("users").child(userId).child("profile_pic").get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                String profilePicUrl = task.getResult().getValue(String.class);
                if (profilePicUrl != null) {
                    // Set profile pic to circle image view using Picasso
                    Picasso.get().load(profilePicUrl).into(userProfilePic);
                }
            } else {
                // Handle database error
                // For example, display an error message or retry the operation
                userProfilePic.setImageResource(R.drawable.hannah);
            }
        });

        mDatabase.child("users").child(userId).child("name").get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                String name = task.getResult().getValue(String.class);
                if (name != null && !name.isEmpty()) {
                    helloName.setText(name);
                } else {
                    // Handle empty or null name
                    // For example, display a default name or show an error message
                    helloName.setText("Default Name");
                }
            } else {
                // Handle database error
                // For example, display an error message or retry the operation
            }
        });

        ImageButton Trainingbtn = findViewById(R.id.trainingBtn);

        Trainingbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, TrainingActivity.class));
            }
        });


        ImageButton recipeBtn = findViewById(R.id.recipeBtn);

        recipeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, RecipeActivity.class));
            }
        });


        ImageButton PetProfilebtn = findViewById(R.id.PetProfilebtn);

        PetProfilebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, PetProfileActivity.class));
            }
        });

        ImageButton MessageBtn = findViewById(R.id.messageBtn);
        MessageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, MessagesActivity.class));
            }
        });

        ImageButton NotificationBtn = findViewById(R.id.notificationBtn);
        NotificationBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, NotificationActivity.class));
            }
        });

        ImageButton UserProfilebtn = findViewById(R.id.UserProfilebtn);

        UserProfilebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, UserProfileActivity.class));
            }
        });



        ImageButton prksbutton = findViewById(R.id.parksBtn);
        prksbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, ParksActivity.class));

            }
        });

        ImageButton nutriTrack = findViewById(R.id.nutritionBtn);
        nutriTrack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, NutritionTrackerActivity.class));

            }
        });



    }

}