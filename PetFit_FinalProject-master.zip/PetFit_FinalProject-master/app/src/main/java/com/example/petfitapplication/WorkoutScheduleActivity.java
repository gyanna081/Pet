package com.example.petfitapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;

import java.util.Calendar;

public class WorkoutScheduleActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout_schedule);

        Button backButton = findViewById(R.id.backButton6);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Close the current activity and go back to the previous activity
            }
        });



        CalendarView calendarView = findViewById(R.id.calendarView4);

        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                // Create a Calendar instance and set the selected date
                Calendar calendar = Calendar.getInstance();
                calendar.set(year, month, dayOfMonth);

                // Start WorkoutSchedule2Activity and pass the selected date as an extra
                Intent intent = new Intent(WorkoutScheduleActivity.this, WorkoutSchedule2Activity.class);
                intent.putExtra("selectedDate", calendar.getTimeInMillis());
                startActivity(intent);
            }
        });
    }
}