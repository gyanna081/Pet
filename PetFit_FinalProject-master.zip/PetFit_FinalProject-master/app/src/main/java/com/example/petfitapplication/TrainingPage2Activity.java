package com.example.petfitapplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class TrainingPage2Activity extends AppCompatActivity {
    private static final int REQUEST_CODE_TIMER = 1; // A unique request code

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_TIMER && resultCode == RESULT_OK) {
            // The timer has finished. Show the WorkoutCompletedFragment.
            WorkoutCompletedFragment fragment = new WorkoutCompletedFragment();
            fragment.show(getSupportFragmentManager(), "workoutCompleted");

            // Then check if the BadgeActivity has been shown before or not
            SharedPreferences sharedPreferences = getSharedPreferences("com.example.petfitapplication", MODE_PRIVATE);
            if (!sharedPreferences.getBoolean("isBadgeActivityShown", false)) {
                // If BadgeActivity has not been shown before, show it now
                startActivity(new Intent(TrainingPage2Activity.this, BadgeActivity.class));
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_training_page2);

        Button btnStartWorkout = findViewById(R.id.btnStartWorkout);

        btnStartWorkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Using startActivityForResult() instead of startActivity()
                Intent intent = new Intent(TrainingPage2Activity.this, IntervalSettingsActivity.class);
                startActivityForResult(intent, REQUEST_CODE_TIMER);
            }
        });

        ImageButton wrkSched = findViewById(R.id.imageButton5);

        wrkSched.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(TrainingPage2Activity.this, WorkoutScheduleActivity.class));
            }
        });
    }
}
