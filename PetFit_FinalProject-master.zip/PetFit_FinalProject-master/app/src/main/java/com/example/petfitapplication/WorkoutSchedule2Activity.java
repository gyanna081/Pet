package com.example.petfitapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.Calendar;

public class WorkoutSchedule2Activity extends AppCompatActivity {

    private ListView listViewTime;
    private long selectedDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout_schedule2);

        Button backButton = findViewById(R.id.backButton7);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Close the current activity and go back to the previous activity
            }
        });


        listViewTime = findViewById(R.id.listViewTime);
        Spinner spinner = findViewById(R.id.spinner);
        String[] workoutOptions = {"Walking/Running Program", "Playtime Programs", "Weight Loss Programs"};

        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, workoutOptions);

        spinner.setAdapter(adapter1);


        selectedDate = getIntent().getLongExtra("selectedDate", 0);

        String[] timeValues = new String[]{
                "12 | 00 | AM",
                "11 | 30 | AM",
                "10 | 45 | AM",
                "9 | 15 | AM",
                "8 | 30 | AM",
                "7 | 45 | AM",
                "6 | 00 | PM",
                "5 | 30 | PM",
                "4 | 45 | PM",
                "3 | 15 | PM",
                "2 | 30 | PM",
                "1 | 45 | PM"
        };

        TimeAdapter adapter = new TimeAdapter(this, R.layout.list_item_time, timeValues);
        listViewTime.setAdapter(adapter);


        listViewTime.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String clickedTime = adapter.getItem(position);
                String selectedOption = spinner.getSelectedItem().toString(); // Get the selected option from the spinner
                String scheduledDateTime = getFormattedDateTime(selectedDate, clickedTime);

                // Start ScheduledActivity and pass the scheduled date, time, and selected option as extras
                Intent intent = new Intent(WorkoutSchedule2Activity.this, ScheduledActivity.class);
                intent.putExtra("scheduledDateTime", scheduledDateTime);
                intent.putExtra("selectedOption", selectedOption);
                startActivity(intent);
            }
        });

    }

    private String getFormattedDateTime(long selectedDate, String time) {
        // Convert the selectedDate to a Calendar instance
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(selectedDate);

        // Extract the year, month, and day from the selectedDate
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        // Extract the hour, minutes, and AM/PM from the time string
        String[] timeParts = time.split(" \\| ");
        int hour = Integer.parseInt(timeParts[0]);
        int minutes = Integer.parseInt(timeParts[1]);
        String amPm = timeParts[2];

        // Set the hour and minute values to the Calendar instance
        calendar.set(year, month, day, hour, minutes);

        // Format the date and time as desired
        // Example: "Walking/Running Program - May 25, 2023, 10:30 AM"
        return String.format("%s - %1$tB %1$te, %1$tY", calendar.getTime());
    }


}
