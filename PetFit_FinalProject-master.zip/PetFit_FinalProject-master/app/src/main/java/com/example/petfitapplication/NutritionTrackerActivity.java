package com.example.petfitapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class NutritionTrackerActivity extends AppCompatActivity {
    private ProgressBar proteinProgressBar;
    private TextView proteinProgressText;
    private EditText proteinInput;

    private ProgressBar calorieProgressBar;
    private TextView calorieProgressText;
    private EditText calorieInput;

    private Button submitButton;
    private TextView editCalorieAmount;

    private int proteinGoal = 100; // Set the desired protein goal here
    private static final String KEY_CALORIE_INTAKE = "calorie_intake";
    private static final String KEY_PROTEIN_INTAKE = "protein_intake";

    private SharedPreferences sharedPreferences;
    private int proteinIntake;
    private int calorieIntake;

    private int calorieGoal = 2000; // Set the desired calorie goal here
    private TextView editProteinAmount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nutrition_tracker);

        Button backbtn = findViewById(R.id.backButton9);

        backbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });



        // Initialize protein views
        proteinProgressBar = findViewById(R.id.proteinProgressBar);
        proteinProgressText = findViewById(R.id.proteinProgressText);
        proteinInput = findViewById(R.id.proteinInput);

        // Set max progress for protein progress bar
        proteinProgressBar.setMax(proteinGoal);

        // Display initial protein progress
        updateProteinProgress();

        // Initialize calorie views
        calorieProgressBar = findViewById(R.id.calorieProgressBar);
        calorieProgressText = findViewById(R.id.calorieProgressText);
        calorieInput = findViewById(R.id.calorieInput);

        // Set max progress for calorie progress bar
        calorieProgressBar.setMax(calorieGoal);

        // Display initial calorie progress
        updateCalorieProgress();

        submitButton = findViewById(R.id.submitButton);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Retrieve protein and calorie values entered by the user
                String proteinAmount = proteinInput.getText().toString();
                String calorieAmount = calorieInput.getText().toString();

                if (!proteinAmount.isEmpty()) {
                    int protein = Integer.parseInt(proteinAmount);
                    proteinIntake += protein;
                    updateProteinProgress();
                }

                if (!calorieAmount.isEmpty()) {
                    int calorie = Integer.parseInt(calorieAmount);
                    calorieIntake += calorie;
                    updateCalorieProgress();
                }
            }
        });

        editCalorieAmount = findViewById(R.id.editCalorieAmount);

        // Set click listener for "Edit Calorie Amount" TextView
        editCalorieAmount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showEditCalorieDialog();
            }
        });


        editProteinAmount = findViewById(R.id.editProteinAmount);

        // Set click listener for "Edit Protein Amount" TextView
        editProteinAmount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showEditProteinDialog();
            }
        });

    }






    private void updateProteinProgress() {
        // Update protein progress bar and text
        proteinProgressBar.setProgress(proteinIntake);
        proteinProgressText.setText(proteinIntake + " / " + proteinGoal);

        // Check if protein goal is reached
        if (proteinIntake >= proteinGoal) {
            // Display congratulatory dialog
            showCongratulatoryDialog1();
        }
    }

    private void updateCalorieProgress() {
        // Update calorie progress bar and text
        calorieProgressBar.setProgress(calorieIntake);
        calorieProgressText.setText(calorieIntake + " / " + calorieGoal);

        // Check if calorie goal is reached
        if (calorieIntake >= calorieGoal) {
            // Display congratulatory dialog
            showCongratulatoryDialog();
        }
    }

    private void showEditCalorieDialog() {
        // Create dialog builder
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Calorie Amount");

        // Create EditText for user input
        final EditText input = new EditText(this);
        input.setText(String.valueOf(calorieGoal));
        builder.setView(input);

        // Set positive button action
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String newCalorieAmount = input.getText().toString();
                int newCalorieGoal = Integer.parseInt(newCalorieAmount);
                if (newCalorieGoal >= calorieIntake) {
                    calorieGoal = newCalorieGoal;
                    calorieProgressBar.setMax(calorieGoal);
                    updateCalorieProgress();
                } else {
                    // Display an error message if the new goal is lower than the current intake
                    Toast.makeText(NutritionTrackerActivity.this, "New goal cannot be lower than current intake", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Set negative button action
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        // Show the dialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void showEditProteinDialog() {
        // Create dialog builder
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Protein Amount");

        // Create EditText for user input
        final EditText input = new EditText(this);
        input.setText(String.valueOf(proteinGoal));
        builder.setView(input);

        // Set positive button action
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String newProteinAmount = input.getText().toString();
                int newProteinGoal = Integer.parseInt(newProteinAmount);
                if (newProteinGoal >= proteinIntake) {
                    proteinGoal = newProteinGoal;
                    proteinProgressBar.setMax(proteinGoal);
                    updateProteinProgress();
                } else {
                    // Display an error message if the new goal is lower than the current intake
                    Toast.makeText(NutritionTrackerActivity.this, "New goal cannot be lower than current intake", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Set negative button action
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        // Show the dialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void showCongratulatoryDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Congratulations!");
        builder.setMessage("You have reached your calorie intake goal!");

        // Add a button to dismiss the dialog
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        // Show the dialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }


    private void showCongratulatoryDialog1() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Congratulations!");
        builder.setMessage("You have reached your protein intake goal!");

        // Add a button to dismiss the dialog
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        // Show the dialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }




}
