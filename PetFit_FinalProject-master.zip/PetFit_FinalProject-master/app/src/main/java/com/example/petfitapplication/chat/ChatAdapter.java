package com.example.petfitapplication.chat;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.petfitapplication.R;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.ChatViewHolder> {

    private List<ChatList> chatLists;
    private DatabaseReference messagesRef; // Reference to the chat messages node in Firebase

    public ChatAdapter(List<ChatList> chatLists, String chatKey) {
        this.chatLists = chatLists;

        // Initialize the Firebase Realtime Database reference to the chat messages node
        FirebaseDatabase database = FirebaseDatabase.getInstance("https://pet-fit-673a5-default-rtdb.asia-southeast1.firebasedatabase.app");
        messagesRef = database.getReference().child("chat").child(chatKey).child("messages");

        // Start listening for new messages
        messagesRef.addChildEventListener(messagesListener);
    }

    // ChildEventListener to listen for new messages and update the UI
    private ChildEventListener messagesListener = new ChildEventListener() {
        @Override
        public void onChildAdded(@NonNull DataSnapshot dataSnapshot, String previousChildName) {
            // Retrieve the new message from the dataSnapshot
            ChatList chatList = dataSnapshot.getValue(ChatList.class);

            // Add the new message to the chatLists list
            chatLists.add(chatList);

            // Notify the adapter that a new message has been added
            notifyDataSetChanged();
        }

        @Override
        public void onChildChanged(@NonNull DataSnapshot dataSnapshot, String previousChildName) {
            // Handle updated message if needed
        }

        @Override
        public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
            // Handle deleted message if needed
        }

        @Override
        public void onChildMoved(@NonNull DataSnapshot dataSnapshot, String previousChildName) {
            // Handle moved message if needed
        }

        @Override
        public void onCancelled(@NonNull DatabaseError databaseError) {
            // Handle database error
        }
    };

    @NonNull
    @Override
    public ChatViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_chat, parent, false);
        return new ChatViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ChatViewHolder holder, int position) {
        ChatList chatList = chatLists.get(position);
        holder.bind(chatList);
    }

    @Override
    public int getItemCount() {
        return chatLists.size();
    }

    public static class ChatViewHolder extends RecyclerView.ViewHolder {
        private TextView messageText;
        private TextView timestampText;
        private TextView nameText;
        private CircleImageView profilePic;

        public ChatViewHolder(@NonNull View itemView) {
            super(itemView);
            messageText = itemView.findViewById(R.id.receivedMessageTextView);
            timestampText = itemView.findViewById(R.id.receivedMessageTimestampTextView);
            nameText = itemView.findViewById(R.id.name);
            profilePic = itemView.findViewById(R.id.profilePic);
        }

        public void bind(ChatList chatList) {
            messageText.setText(chatList.getMessage());
            timestampText.setText(chatList.getTimestamp());

            String userId = chatList.getUserId();
            DatabaseReference userRef = FirebaseDatabase.getInstance().getReference().child("users").child(userId);
            userRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        String name = snapshot.child("name").getValue(String.class);
                        String profilePicUrl = snapshot.child("profile_pic").getValue(String.class);

                        nameText.setText(name);

                        if (profilePicUrl != null && !profilePicUrl.isEmpty()) {
                            Picasso.get().load(profilePicUrl).into(profilePic, new Callback() {
                                @Override
                                public void onSuccess() {
                                    // Image loaded successfully
                                }

                                @Override
                                public void onError(Exception e) {
                                    // Handle error while loading image
                                }
                            });
                        } else {
                            // Handle missing data or empty URL
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    // Handle database error
                }
            });
        }
    }
}
