package com.example.petfitapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

public class UserProfileActivity extends AppCompatActivity {
    private DatabaseReference mDatabase;
    private TextView fullName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        // Initialize Firebase
        FirebaseDatabase database = FirebaseDatabase.getInstance("https://pet-fit-673a5-default-rtdb.asia-southeast1.firebasedatabase.app");
        mDatabase = database.getReference();
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        String userId = currentUser.getUid();

        fullName = findViewById(R.id.profilename);
        ImageView userProfilePic = findViewById(R.id.userProfilePic2);

        mDatabase.child("users").child(userId).child("name").get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                String name = task.getResult().getValue(String.class);
                if (name != null) {
                    fullName.setText(name);
                } else {
                    // Handle missing data or null value
                }
            } else {
                // Handle database error
            }
        });

        mDatabase.child("users").child(userId).child("profile_pic").get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                String profilePicUrl = task.getResult().getValue(String.class);
                if (profilePicUrl != null) {
                    Picasso.get().load(profilePicUrl).into(userProfilePic, new Callback() {
                        @Override
                        public void onSuccess() {
                            // Image loaded successfully
                        }

                        @Override
                        public void onError(Exception e) {
                            // Handle error while loading image
                        }
                    });
                } else {
                    // Handle missing data or null value
                }
            } else {
                // Handle database error
            }
        });

        Button signOutBtn = findViewById(R.id.signOutBtn);
        signOutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
                finish();
                Toast.makeText(UserProfileActivity.this, "You have been signed out.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
