package com.example.petfitapplication;

import com.google.firebase.database.Exclude;
public class Park {
    private String parkId;
    private String name;
    private double latitude;
    private double longitude;

    public Park() {
        // Default constructor required for Firebase
    }

    public Park(String name, double latitude, double longitude) {
        this.name = name;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public String getParkId() {
        return parkId;
    }

    public void setParkId(String parkId) {
        this.parkId = parkId;
    }

    public String getName() {
        return name;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    // Exclude the parkId property from being saved to Firebase
    @Exclude
    public boolean isNewPark() {
        return parkId == null;
    }
}
