package com.example.petfitapplication;

import android.content.Intent;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentManager;

import java.util.Locale;
import android.util.Log;

public class TimerWithAlertsActivity extends AppCompatActivity {

    private TextView tvWorkoutTime;
    private TextView tvReps;
    private TextView tvCurrentSet;
    private Button btnPause;
    private Button btnStop;

    private int workoutTime;
    private int restTime;
    private int reps;
    private int currentSet;

    private CountDownTimer timer;
    private SoundPool soundPool;
    private int countdownSound;
    private int workoutSound;
    private int restSound;
    private int finishSound;

    private enum State {
        PREPARE,
        WORKOUT,
        REST
    }

    private State currentState;
    private long remainingPrepareTime;
    private boolean isPaused;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timer_with_alerts);

        tvWorkoutTime = findViewById(R.id.tv_workout_time);
        tvReps = findViewById(R.id.tv_reps);
        tvCurrentSet = findViewById(R.id.tv_current_set);
        btnPause = findViewById(R.id.btn_pause);
        btnStop = findViewById(R.id.btn_stop);

        Intent intent = getIntent();
        workoutTime = intent.getIntExtra("workoutTime", 0);
        restTime = intent.getIntExtra("restTime", 0);
        reps = intent.getIntExtra("reps", 0);

        tvWorkoutTime.setText(convertSecondsToTime(workoutTime));

        isPaused = false;
        currentSet = 1;
        currentState = State.PREPARE;
        remainingPrepareTime = 5000;

        soundPool = new SoundPool.Builder().build();
        workoutSound = soundPool.load(this, R.raw.workout_sound, 1);
        restSound = soundPool.load(this, R.raw.rest_sound, 1);
        finishSound = soundPool.load(this, R.raw.finish_sound, 1);
        countdownSound = soundPool.load(this, R.raw.countdown_sound, 1);

        startTimer(remainingPrepareTime);

        btnPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isPaused) {
                    resumeTimer();
                    btnPause.setText("Pause");
                } else {
                    pauseTimer();
                    btnPause.setText("Resume");
                }
            }
        });

        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopTimer();
                finish();
            }
        });
    }

    private void startTimer(long duration) {
        timer = new CountDownTimer(duration + 500, 1000) { // Add 500ms to duration
            @Override
            public void onTick(long millisUntilFinished) {
                switch (currentState) {
                    case PREPARE:
                        remainingPrepareTime = millisUntilFinished;
                        tvCurrentSet.setText("Prepare: " + millisUntilFinished / 1000);
                        if (millisUntilFinished < 4000) { // Play sound at less than 4 seconds
                            soundPool.play(countdownSound, 1, 1, 0, 0, 1);
                        }
                        break;
                    case WORKOUT:
                        tvCurrentSet.setText("Workout");
                        tvWorkoutTime.setText(convertSecondsToTime((int) (millisUntilFinished / 1000)));
                        break;
                    case REST:
                        tvCurrentSet.setText("Rest");
                        tvWorkoutTime.setText(convertSecondsToTime((int) (millisUntilFinished / 1000)));
                        break;
                }
            }

            @Override
            public void onFinish() {
                switch (currentState) {
                    case PREPARE:
                        currentState = State.WORKOUT;
                        soundPool.play(workoutSound, 1, 1, 0, 0, 1);
                        Log.d("DEBUG", "Playing workoutSound after prepare");
                        tvReps.setText("Set " + (currentSet));
                        startTimer(workoutTime * 1000);
                        break;
                    case WORKOUT:
                        currentSet++;
                        if (currentSet <= reps) {
                            currentState = State.REST;
                            soundPool.play(restSound, 1, 1, 0, 0, 1);
                            Log.d("DEBUG", "Playing restSound after workout");
                            startTimer(restTime * 1000);
                        } else {
                            soundPool.play(finishSound, 1, 1, 0, 0, 1);
                            Log.d("DEBUG", "Playing finishSound after final workout");
                            Toast.makeText(TimerWithAlertsActivity.this, "Training Finished!", Toast.LENGTH_SHORT).show();

                            // Show the WorkoutCompletedFragment
                            showWorkoutCompletedFragment();
                        }
                        break;
                    case REST:
                        currentState = State.WORKOUT;
                        soundPool.play(workoutSound, 1, 1, 0, 0, 1);
                        Log.d("DEBUG", "Playing workoutSound after rest");
                        tvReps.setText("Set " + (currentSet));
                        startTimer(workoutTime * 1000);
                        break;
                }
            }
        }.start();
    }

    private void pauseTimer() {
        timer.cancel();
        isPaused = true;
    }

    private void resumeTimer() {
        isPaused = false;
        long remainingTime;
        switch (currentState) {
            case PREPARE:
                remainingTime = remainingPrepareTime;
                break;
            case WORKOUT:
            case REST:
                remainingTime = convertTimeToSeconds(tvWorkoutTime.getText().toString()) * 1000;
                break;
            default:
                throw new IllegalStateException("Unexpected state: " + currentState);
        }
        startTimer(remainingTime);
    }

    private void stopTimer() {
        timer.cancel();
        soundPool.release();
    }

    private String convertSecondsToTime(int timeInSeconds) {
        int minutes = timeInSeconds / 60;
        int seconds = timeInSeconds % 60;
        return String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);
    }

    private int convertTimeToSeconds(String time) {
        String[] parts = time.split(":");
        int minutes = Integer.parseInt(parts[0]);
        int seconds = Integer.parseInt(parts[1]);
        return minutes * 60 + seconds;
    }

    private void showWorkoutCompletedFragment() {
        FragmentManager fragmentManager = getSupportFragmentManager();
        DialogFragment dialogFragment = new WorkoutCompletedFragment();
        dialogFragment.show(fragmentManager, "workoutCompleted");
    }
}
