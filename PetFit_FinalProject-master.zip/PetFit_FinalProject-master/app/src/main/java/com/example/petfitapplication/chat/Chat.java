package com.example.petfitapplication.chat;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.petfitapplication.MemoryData;
import com.example.petfitapplication.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

public class Chat extends AppCompatActivity {
    private FirebaseDatabase database;
    private DatabaseReference databaseReference;
    private String chatKey;
    private TextView nameTV;
    private String getUserID = "";
    private String getUID;
    private CircleImageView profilePic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        database = FirebaseDatabase.getInstance("https://pet-fit-673a5-default-rtdb.asia-southeast1.firebasedatabase.app");
        databaseReference = database.getReference();

        final ImageView backBtn = findViewById(R.id.backBtn);
        nameTV = findViewById(R.id.name);
        profilePic = findViewById(R.id.profilePic);

        final String getName = getIntent().getStringExtra("name");
        chatKey = getIntent().getStringExtra("chat_key");
        getUID = getIntent().getStringExtra("uid");

        getUserID = MemoryData.getData(Chat.this);

        nameTV.setText(getName);

        if (chatKey == null || chatKey.isEmpty()) {
            databaseReference.child("chat").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    chatKey = String.valueOf(snapshot.getChildrenCount() + 1);
                    createChatNode();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    // Handle onCancelled event
                }
            });
        } else {
            sendMessage();
        }

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    private void createChatNode() {
        databaseReference.child("chat").child(chatKey).child("user_1").setValue(getUserID);
        databaseReference.child("chat").child(chatKey).child("user_2").setValue(getUID);

        if (getUID != null) {
            loadProfilePicture(getUID);
        } else {
            // Handle null UID case
        }

        sendMessage();
    }

    private void loadProfilePicture(String uid) {
        DatabaseReference userRef = databaseReference.child("users").child(uid);

        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String profilePicUrl = snapshot.child("profile_pic").getValue(String.class);
                    String userName = snapshot.child("name").getValue(String.class);

                    if (profilePicUrl != null && !profilePicUrl.isEmpty()) {
                        Picasso.get().load(profilePicUrl).into(profilePic, new Callback() {
                            @Override
                            public void onSuccess() {
                                // Image loaded successfully
                            }

                            @Override
                            public void onError(Exception e) {
                                // Handle error while loading image
                            }
                        });
                    } else {
                        // Handle missing data or empty URL
                    }

                    if (userName != null && !userName.isEmpty()) {
                        nameTV.setText(userName);
                    } else {
                        // Handle missing user name
                    }
                } else {
                    // Handle snapshot does not exist
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle database error
            }
        });
    }

    private void sendMessage() {
        final EditText messageEditText = findViewById(R.id.messageEditTxt);
        final ImageView sendBtn = findViewById(R.id.sendBtn);

        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String getTxtMessage = messageEditText.getText().toString();
                final String currentTimestamp = String.valueOf(System.currentTimeMillis()).substring(0, 10);

                MemoryData.saveLastMsgTS(currentTimestamp, chatKey, Chat.this);

                ChatList chatList = new ChatList(getTxtMessage, getUserID, currentTimestamp);
                databaseReference.child("chat").child(chatKey).child("messages").child(currentTimestamp).setValue(chatList);

                messageEditText.setText("");
            }
        });
    }
}
