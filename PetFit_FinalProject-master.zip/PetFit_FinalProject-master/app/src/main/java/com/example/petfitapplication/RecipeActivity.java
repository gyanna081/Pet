package com.example.petfitapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class RecipeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe);


        ImageButton backbtn = findViewById(R.id.imageButton7);

        backbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(RecipeActivity.this, MainActivity.class));

            }
        });


        Button mealDetails1 = findViewById(R.id.button9);

        mealDetails1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(RecipeActivity.this, MealDetails1Activity.class));

            }
        });

        Button mealDetails2 = findViewById(R.id.button10);

        mealDetails2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(RecipeActivity.this, MealDetails2Activity.class));

            }
        });

        Button mealDetails3 = findViewById(R.id.button11);

        mealDetails3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(RecipeActivity.this, MealDetails3Activity.class));

            }
        });


        ImageButton leanMeat = findViewById(R.id.imageButton10);

        leanMeat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(RecipeActivity.this, Category1Activity.class));

            }
        });

        ImageButton veggy = findViewById(R.id.imageButton11);

        veggy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(RecipeActivity.this, Category2Activity.class));

            }
        });


        ImageButton fish = findViewById(R.id.imageButton15);

        fish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(RecipeActivity.this, Category3Activity.class));

            }
        });







    }

}