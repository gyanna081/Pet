package com.example.petfitapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class SignUpActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        Button yesButton = findViewById(R.id.yesButton);
        Button noButton = findViewById(R.id.noButton);
        Button nextBtn = findViewById(R.id.nextBtn);
        View formLayout = findViewById(R.id.formLayout);

        yesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                formLayout.setVisibility(View.VISIBLE);
                yesButton.setBackgroundTintList(getResources().getColorStateList(R.color.orange));
                noButton.setBackgroundTintList(getResources().getColorStateList(R.color.v_light_orange));
            }
        });

        noButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                formLayout.setVisibility(View.GONE);
                noButton.setBackgroundTintList(getResources().getColorStateList(R.color.orange));
                yesButton.setBackgroundTintList(getResources().getColorStateList(R.color.v_light_orange));
            }
        });

        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(SignUpActivity.this,SignUp2Activity.class));
            }
        });
    }
}