package com.example.petfitapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;


import java.util.Locale;

public class IntervalSettingsActivity extends AppCompatActivity {
    private static final int REQUEST_CODE_TIMER = 1;

    // Declare UI elements
    private EditText etWorkoutTime;
    private EditText etRestTime;
    private EditText etReps;
    private Button btnStart;
    private Button btnWorkoutIncrement;
    private Button btnWorkoutDecrement;
    private Button btnRestIncrement;
    private Button btnRestDecrement;
    private Button btnRepsIncrement;
    private Button btnRepsDecrement;

    // Declare variables to store user input
    private int workoutTime;
    private int restTime;
    private int reps;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interval_settings);


        Button backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> {
            // Start a new activity
            Intent intent = new Intent(IntervalSettingsActivity.this, TrainingPage2Activity.class);
            startActivity(intent);
        });


        // Initialize UI elements
        etWorkoutTime = findViewById(R.id.et_workout_time);
        etRestTime = findViewById(R.id.et_rest_time);
        etReps = findViewById(R.id.et_reps);
        btnStart = findViewById(R.id.btn_start);

        // Initialize increment and decrement buttons
        btnWorkoutIncrement = findViewById(R.id.btn_workout_increment);
        btnWorkoutDecrement = findViewById(R.id.btn_workout_decrement);
        btnRestIncrement = findViewById(R.id.btn_rest_increment);
        btnRestDecrement = findViewById(R.id.btn_rest_decrement);
        btnRepsIncrement = findViewById(R.id.btn_reps_increment);
        btnRepsDecrement = findViewById(R.id.btn_reps_decrement);

        // Set click listeners for increment and decrement buttons
        btnWorkoutIncrement.setOnClickListener(v -> incrementWorkoutTime());
        btnWorkoutDecrement.setOnClickListener(v -> decrementWorkoutTime());
        btnRestIncrement.setOnClickListener(v -> incrementRestTime());
        btnRestDecrement.setOnClickListener(v -> decrementRestTime());
        btnRepsIncrement.setOnClickListener(v -> incrementReps());
        btnRepsDecrement.setOnClickListener(v -> decrementReps());


        // Set a click listener for the start button
        btnStart.setOnClickListener(v -> {
            try {
                // Convert the workout and rest times to seconds before starting the timer
                workoutTime = convertToSeconds(etWorkoutTime.getText().toString());
                restTime = convertToSeconds(etRestTime.getText().toString());
                reps = Integer.parseInt(etReps.getText().toString());

                // Validate the user input
                if (workoutTime > 0 && restTime > 0 && reps > 0) {
                    // Create an intent to start the TimerWithAlertsActivity and pass the user input as extras
                    Intent intent = new Intent(IntervalSettingsActivity.this, TimerWithAlertsActivity.class);
                    intent.putExtra("workoutTime", workoutTime);
                    intent.putExtra("restTime", restTime);
                    intent.putExtra("reps", reps);

                    // Start the TimerWithAlertsActivity and expect a result
                    startActivityForResult(intent, REQUEST_CODE_TIMER);
                } else {
                    // Show a toast message if the user input is invalid
                    Toast.makeText(IntervalSettingsActivity.this, "Please enter positive values for all fields", Toast.LENGTH_SHORT).show();
                }
            } catch (NumberFormatException e) {
                Toast.makeText(IntervalSettingsActivity.this, "Invalid time format. Please enter times as MM:SS", Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_TIMER && resultCode == RESULT_OK) {
            // The training has finished. Pass this result back to TrainingPage2Activity.
            setResult(RESULT_OK);
            finish();
        }
    }



    // Increment and decrement methods
    private void incrementWorkoutTime() {
        String workoutTimeString = etWorkoutTime.getText().toString();
        int workoutTime = convertToSeconds(workoutTimeString);
        workoutTime++;
        etWorkoutTime.setText(convertToMinutesAndSeconds(workoutTime));
    }

    private void decrementWorkoutTime() {
        String workoutTimeString = etWorkoutTime.getText().toString();
        int workoutTime = convertToSeconds(workoutTimeString);
        if (workoutTime > 0) {
            workoutTime--;
            etWorkoutTime.setText(convertToMinutesAndSeconds(workoutTime));
        }
    }

    private void incrementRestTime() {
        String restTimeString = etRestTime.getText().toString();
        int restTime = convertToSeconds(restTimeString);
        restTime++;
        etRestTime.setText(convertToMinutesAndSeconds(restTime));
    }

    private void decrementRestTime() {
        String restTimeString = etRestTime.getText().toString();
        int restTime = convertToSeconds(restTimeString);
        if (restTime > 0) {
            restTime--;
            etRestTime.setText(convertToMinutesAndSeconds(restTime));
        }
    }
    private void incrementReps() {
        int reps = Integer.parseInt(etReps.getText().toString());
        etReps.setText(String.valueOf(reps + 1));
    }

    private void decrementReps() {
        int reps = Integer.parseInt(etReps.getText().toString());
        if (reps > 0) {
            etReps.setText(String.valueOf(reps - 1));
        }
    }

    // Method to convert time from the format MM:SS to seconds
    private int convertToSeconds(String time) {
        String[] parts = time.split(":");
        int minutes = Integer.parseInt(parts[0]);
        int seconds = Integer.parseInt(parts[1]);
        return minutes * 60 + seconds;
    }

    // Method to convert seconds back into MM:SS format
    private String convertToMinutesAndSeconds(int time) {
        int minutes = time / 60;
        int seconds = time % 60;
        return String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);
    }
}
